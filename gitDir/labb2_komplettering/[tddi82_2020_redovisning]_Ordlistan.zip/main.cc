// Information om komplettering:
//   Siffrorna hänvisar till rättningsprotokollet som finns på
//   kurshemsidan -> laboration -> "UPP-gruppens gemensamma rättningsprotokoll"
//   Kompletteringen kan gälla hela filen och alla filer i labben,
//   så får ni komplettering på en sak, kan samma sak förekomma på
//   fler ställen utan att jag skrivit det.
//   Har ni frågor om kompletteringen kan ni maila mig på:
//   eriek993@student.liu.se

//Komplettering: anrop utan flagga fångas inte korrekt.
//Komplettering: anrop utan extra flagga till -o ger felaktig felutskrift.
//Komplettering: flagga -o ger inte korrekt utskrift. jag får ett par korta
//               rader och sedan en lång rad.
//Komplettering: ogiltig flagga vid anrop ger ingen felmedelande.
//Komplettering: Er filtrering är inte korrekt. Kör med den givna test-filen
//               så ser ni vad som inte blir rätt.
//Komplettering: testa att köra programet med er källkod som indata. Detta ger en krach.
//               tips: kolla på om ni lämnar ord utan giltiga tecken i någon lista.

//Komplettering: RADBRYT! max 80 tecken per rad!
//Komplettering: ta bort en del av all dessa arga kommentarer. er kod blir svår att läsa om
//               det är kommentarer överallt inne i koden. Kommentera medvetet och genomtänkt.
//               Och ni behöver inte ha CAPS-lock för att skriva kommentarer!

//Komplettering: kom ihåg att inte kopiera komplexa datatyper i onödan.
//               kolla igenom koden och se till att ni inte gör det!

#include <iostream>
#include <fstream>
#include <cctype>
#include <algorithm>
#include <sstream>
#include <iterator>
#include <vector>
#include <map>
#include <unordered_map>
#include <iomanip>

using namespace std;

//MÅSTE VARA GENERELLT

ostream& operator<<(std::ostream &os, std::pair<std::string, int> const &v);

int main(int argc, char *argv[])
{
    vector<string> args {argv, argv + argc};
    //vector<string> v (args.size());
    //copy(args.begin(), args.end(), v.begin());

    ifstream inFileStream{args.at(1)};
    std::vector<string> words{std::istream_iterator<string>{inFileStream}, std::istream_iterator<string>{}};

    stringstream ss{};

        //TA BORT SKRÄP I BÖRJAN
        transform(words.begin(), words.end(), /*OBS!*/words.begin()/*OBS! --> RETURVÄRDET I LAMBDA-FUNKTIONEN ÄNDRAR WORDS*/, [&words, &ss](string word)
        {
            //ERSÄTTER ALLA SKRÄP-TECKEN MED MELLANRUM DÄR VI TAR BORT TECKEN
            auto it {find_if(word.begin(),word.end(),[](char & c){return isalpha(c);})};
            
            if ( any_of(word.begin(), it, [](char c){return c != '\"' && c != '\'' && c != '(';}))
            {
                return "";
            }
            return word.c_str();
        });


        //TA BORT SKRÄP I SLUTET
        transform(words.begin(), words.end(), /*OBS!*/words.begin()/*OBS! --> RETURVÄRDET I LAMBDA-FUNKTIONEN ÄNDRAR WORDS*/, [&words, &ss](string word)
        {
            //ERSÄTTER ALLA SKRÄP-TECKEN MED MELLANRUM DÄR VI TAR BORT TECKEN
            auto it {find_if(make_reverse_iterator(word.end()),make_reverse_iterator(word.begin()),[](char & c){return isalpha(c);})};
            
            if ( any_of(make_reverse_iterator(word.end()), it, [](char c){return c != '"' && c != '\'' && c != ')' && c != '!' && c != '?' && c != ';' && c != ',' && c != ':' && c != '.';}))
            {
                return "";
            }
            return word.c_str();
        });


        transform(words.begin(), words.end(), words.begin(), [](string word)
        {   
            auto firstLetter = find_if(word.begin(), word.end(), [](char & c)
            {
                return isalpha(c);
            });
            auto lastLetter = find_if(make_reverse_iterator(word.end()),make_reverse_iterator(word.begin()),[](char & c)
            {
                return isalpha(c);
            });
            if ( any_of(lastLetter, make_reverse_iterator(firstLetter), [](char c){return !isalpha(c) && c != '-' && c != '\'';}))
            {
                return "";
            }
            return word.c_str();
        });
    
        //TA BORT SKRÄP I SLUTET
        transform(words.begin(), words.end(), words.begin(), [&words](string word)
        {

	  
            //ERSÄTTER ALLA SKRÄP-TECKEN MED MELLANRUM DÄR VI TAR BORT TECKEN
            auto current{word.begin()};
            auto it{find_if(word.begin(),word.end(),[&current,&word](char & c)
                {
                    if(c == '-')
                    {
                        //ERSÄTTER INTE '-' OM BOKSTÄVER BREVID
                        if(isalpha(*prev(current)) && isalpha(*next(current)))
                        {
                            ++current;
                            return false;
                        }
                        return true;
                    }
                    else if(c == '\'')
                    {
                        auto lastLetter = find_if(make_reverse_iterator(word.end()),make_reverse_iterator(word.begin()),[](char & c)
                        {
                            return isalpha(c);
                        });
                        if(*lastLetter == 's')
                        {
                            if(*next(lastLetter) == '\'')
                            {
                                return false;
                            }
                            return true;
                        }
                    }
                    ++current;
                    return false;
                }
            )};
            if (it != word.end())
            {
                return "";
            }
            return word.c_str();
        });

    auto it = remove_if(words.begin(), words.end(), [](string & word)
    {
        return word == "" || word.size() < 3;
    });

    words.erase(it,words.end());

    transform(words.begin(), words.end(), words.begin(), [](string word)
        {
            auto it = remove_if(word.begin(), word.end(), [](char& c)
                {
                    if (c != '-' && c != '\'' && !isalpha(c))
                    {
                        return true;
                    }
                    return false;
                });
            word.erase(it,word.end());

            string tmp{"'s"};
            word.erase(search(word.begin(), word.end(), tmp.begin(), tmp.end()), word.end());
            
            return word;
        }
    );

    transform(words.begin(), words.end(), words.begin(), [](string word)
    {
        transform(word.begin(),word.end(), word.begin(),[](char & c)
        {
            if(isupper(c))
            {
                return static_cast<char>(c + 32);
            }
            return c;
        });
    
    return word.c_str();
    });

//Komplettering: Kodupprepning.
    
    if(args.at(2) == "-a")
    {
        transform(words.begin(), words.end(), words.begin(), [&words](string & word)
        {
            auto longestWord {max_element(words.begin(),words.end())};
            word.insert(word.end(),longestWord->size() - word.size(),' ');

            return word;
        });

        //VECTOR AV PAR
        vector<pair<string, int>> pairs{words.size()};
        
        transform(words.begin(), words.end(), pairs.begin(), [&words](string & word)
        {
            return pair<string, int>(word, count(words.begin(), words.end(), word));
        });

        //VECTOR AV PAR TILL MAP
        map<string, int> m{pairs.begin(), pairs.end()};

        std::copy( m.begin(), m.end(), ostream_iterator<pair<string, int>>(cout, "\n") );
    }
    else if(args.at(2) == "-f")
    {
        transform(words.begin(), words.end(), words.begin(), [&words](string & word)
        {
            auto longestWord {max_element(words.begin(),words.end())};
            word.insert(word.begin(),longestWord->size() - word.size(),' ');

            return word;
        });

        //VECTOR AV PAR
        vector<pair<string, int>> pairs{words.size()};
        
        transform(words.begin(), words.end(), pairs.begin(), [&words](string & word)
        {
            return pair<string, int>(word, count(words.begin(), words.end(), word));
        });

        //VECTOR AV PAR TILL MAP

	//Komplettering: varför kopiera till en map och sen direkt till en vektor.
	//               Det är bara slöseri med minne.
        map<string, int> m{pairs.begin(), pairs.end()};

        vector<pair<string, int>> v{m.begin(),m.end()};

        sort(v.begin(), v.end(), [](pair<string,int> pair1, pair<string,int> pair2)
        {
            return pair1.second > pair2.second;
        });

        std::copy( v.begin(), v.end(), ostream_iterator<pair<string, int>>(cout , "\n") );
    }
    else if(args.at(2) == "-o")
    {
        //FOR_EACH!!!
        int maxRowLength{stoi(args.at(3))};
        for_each(words.begin(), words.end(), [&maxRowLength, &args](string & word)
        {
            if(word.size() < maxRowLength)
            {
                cout << word << " ";
                maxRowLength -= (word.size() + 1);
            }
            else
            {
                cout << '\n';
                maxRowLength = stoi(args.at(3));
                cout << word << " ";
                maxRowLength -= (word.size() + 1);
            }
        });
        cout << endl;
    }
}

namespace std
{
    ostream& operator<<(ostream &os, pair<string, int> const &v) {
        os << v.first << setw(3) << v.second;
        return os;
    }
}


// setw(longestWord)
